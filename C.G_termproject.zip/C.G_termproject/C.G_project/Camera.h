#pragma once
class Camera
{
};

