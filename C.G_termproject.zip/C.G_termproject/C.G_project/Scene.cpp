#include "Scene.h"

Scene::Scene()
{
}

Scene::~Scene()
{
}

void Scene::BuildObject()
{
	bullet = new Bullet();
}
